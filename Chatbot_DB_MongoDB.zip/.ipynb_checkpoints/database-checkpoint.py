# MongoDB Client 모듈
# database.py
from pymongo import MongoClient

# MongoDB에 연결 
client = MongoClient('localhost',27017)
db = client['chatbot']                         # DB name : chatbot
conversaions_collection = db['conversations']  # collection name : conversations

def init_db():
    pass   # MongoDB에서는 컬렉션이 필요할 때 자동으로 생성되므로 초기화 과정이 필요 없다.


# 저장하기
def save_conversation(question,answer):
    conversaion = {
        'question' : question,
        'answer' : answer
    }
    conversaions_collection.insert_one(conversaion)

# 불러오기
def get_conversations():
    conversions = conversaions_collection.find({})
    return list(conversions)

# 삭제하기
def delete_conversation(d):
    if d :
        conversaions_collection.delete_one(d)
    
# 데이터베이스 연결 종료 (원한다면, 하지만 일반적으로 MongoDB 연결을 유지해도 문제 없습니다.)
def close_connection():
    client.close()

if __name__ == '__main__':
    init_db()
    save_conversation('Hi','Hello how are you?')
    save_conversation('Bye','Good bye. Have a good time.')
    print(get_conversations())
    close_connection()
