# OpenAI API 사용 고객 서비스 챗봇 만들기

from flask import Flask,render_template,request,jsonify
from openai import OpenAI
from dotenv import load_dotenv
import os

# .env 파일의 내용 불러오기
load_dotenv("C:/env/.env")
API_KEY = os.getenv("OPENAI_API_KEY")

# Flask APP 생성
app = Flask(__name__)

# OpenAI API 요청 client 객체 생성
client = OpenAI(api_key=API_KEY) 

### 질문한 내용을 Context로 계속 유지하면서 질문하기
@app.route("/")
def home():
    return render_template("index.html")

# 대화 히스토리를 저장할 변수
conversation_history = []

@app.route("/get_response", methods=["POST"])
def get_response():
    user_message = request.json.get("message")
    conversation_history.append({"role": "user", "content": user_message})
    print(conversation_history)
                                
    # OpenAI 모델에 요청
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=conversation_history,
        # max_tokens=300,
        n=1,
        stop=None,
        temperature=0.2,
    )

    bot_response = response.choices[0].message.content
    return jsonify({"response": bot_response})

if __name__ == "__main__":
    app.run(debug=False)